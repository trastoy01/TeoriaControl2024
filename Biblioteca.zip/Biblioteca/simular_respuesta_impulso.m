function simular_respuesta_impulso(G)
    % SIMULAR_RESPUESTA_IMPULSO Simula la respuesta al impulso de un sistema
    % con una función de transferencia G.
    %
    % G: objeto de función de transferencia de MATLAB
    
    % Verifica si el argumento G es una función de transferencia
    if ~isa(G, 'tf')
        error('El argumento debe ser una función de transferencia de MATLAB.');
    end
    
    % Calcula la respuesta al impulso
    try
        [respuesta, tiempo] = impulse(G);
        
        % Crea la figura para el gráfico
        figure;
        
        % Grafica la respuesta al impulso
        plot(tiempo, respuesta);
        grid on;
        
        % Personaliza el gráfico con título y etiquetas
        title('Respuesta al Impulso del Sistema');
        xlabel('Tiempo (s)');
        ylabel('Respuesta');
        
    catch me
        % En caso de un error en la simulación, muestra un mensaje
        error('Error al simular la respuesta al impulso: %s', me.message);
    end
end
