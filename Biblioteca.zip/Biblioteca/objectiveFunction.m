function J = objectiveFunction(x)
    K = x(1);
    a = x(2);
    
    % Simular la respuesta del sistema con las ganancias actuales
    % Aquí necesitarías integrar tu modelo del sistema y la simulación
    % Por ejemplo, usando la función step o simulink
    sys = getTransferFunction(K, a); % Suponiendo que esta función devuelve la TF
    info = stepinfo(sys);
    
    % Define la función objetivo
    Mp = info.Overshoot;
    ts = info.SettlingTime;
    Mp_max = 20;  % Sobrepaso máximo permitido
    ts_max = 2;   % Tiempo de establecimiento máximo permitido
    Mp_penalty = max(0, Mp - Mp_max);
    ts_penalty = max(0, ts - ts_max);
    % Penalización por no cumplir los requisitos
    J = (Mp_penalty)^4 + (ts_penalty)^4;
end
function sys = getTransferFunction(K, a)
    % Definir la función de transferencia basada en K y a
    % Esta función deberá ser implementada según el modelo de tu sistema
    s = tf('s');
    numerator = [15];
    denominator = [1 10 17 18];

    F = tf(numerator, denominator);
    PD = (s+2.501);
    PI = (s+a)/s;
    G = series(series(PI, PD),F);
    sys = feedback(series(K,G), 1);  % Ejemplo de función de transferencia
end