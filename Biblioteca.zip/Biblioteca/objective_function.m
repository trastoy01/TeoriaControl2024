function J = objectiveFunction(x)
    K = x(1);
    a = x(2);
    
    % Simular la respuesta del sistema con las ganancias actuales
    % Aquí necesitarías integrar tu modelo del sistema y la simulación
    % Por ejemplo, usando la función step o simulink
    sys = getTransferFunction(K, a); % Suponiendo que esta función devuelve la TF
    info = stepinfo(sys);
    
    % Define la función objetivo
    Mp = info.Overshoot;
    ts = info.SettlingTime;
    Mp_max = 20;  % Sobrepaso máximo permitido
    ts_max = 2;   % Tiempo de establecimiento máximo permitido
    
    % Penalización por no cumplir los requisitos
    J = (Mp - Mp_max)^2 + (ts - ts_max)^2;
end
