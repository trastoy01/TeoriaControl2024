function [ceros, polos, ganancia] = calcular_polos_ceros_ganancia(G)
    % CALCULAR_POLOS_CEROS_GANANCIA Calcula los polos, ceros y la ganancia
    % de una función de transferencia dada.
    %
    % G: objeto de función de transferencia de MATLAB
    %
    % Devuelve los ceros, polos y la ganancia del sistema.

    % Verifica si el argumento G es una función de transferencia
    if ~isa(G, 'tf')
        error('El argumento debe ser una función de transferencia de MATLAB.');
    end
    
    try
        % Obtiene los ceros y polos de la función de transferencia
        ceros = zero(G);
        polos = pole(G);
        
        % Obtiene la ganancia de la función de transferencia
        % La ganancia se puede calcular como el límite de G(s) cuando s tiende a 0
        ganancia = dcgain(G);
        
        % Muestra los resultados
        disp('Ceros del sistema: ');
        disp(ceros);
        
        disp('Polos del sistema: ');
        disp(polos);
        
        disp(['Ganancia del sistema: ', num2str(ganancia)]);
        
    catch me
        % En caso de un error durante el cálculo, muestra un mensaje
        error('Error al calcular polos, ceros y ganancia: %s', me.message);
    end
end
