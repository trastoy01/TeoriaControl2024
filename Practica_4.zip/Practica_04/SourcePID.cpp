#include <Arduino.h>
#include "HeadPID.h"

HeadPID::HeadPID(float Kp, float Ki, float Kd, float dt) { // Constructor de la clase
    this->Kp = Kp; //this es un puntero que apunta a la direccion de memoria de la variable Kp de la clase
    this->Ki = Ki;
    this->Kd = Kd;
    this->dt = dt;
    
    // Inicializacion de los valores del controlador PID (4.1.1)
    previous_error = 0;         // Error anterior
    integral = 0;               // Integral
    error = 0;                  // Error    

    A0 = Kp + Ki * dt + Kd / dt;    // Coeficiente A0 para el controlador PID
    A1 = - Kp - 2 * Kd / dt;        // Coeficiente A1 para el controlador PID
    A2 = Kd / dt;                   // Coeficiente A2 para el controlador PID

    // Inicializacion del vector de errores del filtro IIR (4.1.2)
    error[2] = 0;   // Error en el instante k-2 
    error[1] = 0;   // Error en el instante k-1
    error[0] = 0;   // Error en el instante k

    // Inicializacion de los valores de los coeficientes del filtro pasa baja en el termino derivativo (4.1.3)
    d0 = 0;     // Error en el instante k - error en el instante k-1    
    d1 = 0;     // Error en el instante k-1 - error en el instante k-2
    fd0 = 0;    // Salida del filtro en el instante k
    fd1 = 0;    // Salida del filtro en el instante k-1

    N = 5; // Orden del filtro pasa baja
    tau = Kd / ( Kp * N );      // Constante de tiempo del filtro pasa baja
    alpha = dt / (2* tau );     // Coeficiente alpha del filtro pasa baja
    alpha_1 = alpha / ( alpha + 1);   // Coeficiente alpha_1 del filtro pasa baja
    alpha_2 = ( alpha - 1) / ( alpha + 1);  // Coeficiente alpha_2 del filtro pasa baja  
}

    
    // Inicializacion de los valores de los coeficientes del filtro pasa baja en el termino derivativo (4.1.3)
void HeadPID::setSetpoint(float setpoint) {
    this->setpoint = setpoint; 
}
void HeadPID::setTunings(float Kp, float Ki, float Kd) {
    // Implementacion de controlador PID en tiempo discreto (4.1.1). Se hace este metodo para poder cambiar los valores de Kp, Ki y Kd
    this->Kp = Kp;       
    this->Ki = Ki;
    this->Kd = Kd;
    A0 = Kp + Ki * dt + Kd / dt;
    A1 = - Kp - 2 * Kd / dt;
    A2 = Kd / dt;
    tau = Kd / ( Kp * N );
    alpha = dt / (2* tau );
    alpha_1 = alpha / ( alpha + 1);
    alpha_2 = ( alpha - 1) / ( alpha + 1);
}

double HeadPID::compute(double measured_value) {
    // Implementacion de controlador PID en tiempo discreto (4.1.1)
    error = setpoint - measured_value;
    integral = integral + error * dt;
    derivative = ( error - previous_error ) / dt;
    output = Kp * error + Ki * integral + Kd * derivative;
    previous_error = error;

    // Implementacion de PID como un filtro IIR (4.1.2)
    error[2] = error[1];
    error[1] = error[0];
    error[0] = setpoint - measured_value;
    output = A0 * error[0] + A1 * error[1] + A2 * error[2];

    // Implementacion de filtro pasa baja en el termino derivativo (4.1.3)
    d0 = error[0] - error[1];
    d1 = error[1] - error[2];
    fd0 = alpha_1 * fd1 + alpha_2 * d0;
    fd1 = alpha_1 * fd0 + alpha_2 * d1;
    output = A0 * error[0] + A1 * error[1] + A2 * error[2] + A0d * fd0 + A1d * fd1;
    return output;
}





