/*
PRÁCTICA 4: CONTROLADORES PID EN TIEMPO DISCRETO
Implementar los tres pseudocodigos anteriores en el microcontrolador ESP32, empleado para
la realizacion del proyecto del pendulo invertido
Integrar los codigo realizados en una biblioteca de control PID de vuestra realizacion
*/

/*
4.1.1. Implementacion de controlador PID en tiempo discreto

previous_error := 0
integral := 0
start :
    error := setpoint - measured_value
    integral := integral + error * dt
    derivative := ( error - previous_error ) / dt
    output := Kp * error + Ki * integral + Kd * derivative
    previous_error := error
    wait ( dt )
    goto start
*/

/*
4.1.2. PID como un filtro IIR (Infinite Impulse Response)

A0 := Kp + Ki * dt + Kd / dt
A1 := - Kp - 2 * Kd / dt
A2 := Kd / dt
error [2] := 0
error [1] := 0
error [0] := 0
output := u0 // Normalmente el valor inicial del actuador
start :
    error [2] := error [1]
    error [1] := error [0]
    error [0] := setpoint - measured_value
    output := A0 * error [0] + A1 * error [1] + A2 * error [2]
    wait ( dt )
    goto start    
*/

/*
4.1.3. Filtro pasa baja en el termino derivativo

A0 := Kp + Ki * dt
A1 := - Kp
error [2] := 0 // e (t -2)
error [1] := 0 // e (t -1)
error [0] := 0 // e ( t )
output := u0 // Normalmente el valor inicial del actuador
A0d := Kd / dt
A1d := - 2.0* Kd / dt
A2d := Kd / dt
N := 5
tau := Kd / ( Kp * N ) // Constante de tiempo del filtro pasa baja
alpha := dt / (2* tau )
alpha_1 = alpha / ( alpha + 1)
alpha_2 = ( alpha - 1) / ( alpha + 1)
d0 := 0
d1 := 0
fd0 := 0
fd1 := 0
loop :
    error [2] := error [1]
    error [1] := error [0]
    error [0] := setpoint - measured_value
    // PI
    output := output + A0 * error [0] + A1 * error [1]
    // Filtered D
    d1 := d0
    d0 := A0d * error [0] + A1d * error [1] + A2d * error [2]
    fd1 := fd0
    fd0 := alpha_1 * ( d0 + d1 ) - alpha_2 * fd1
    output := output + fd0
    wait ( dt )
    goto loop*/

#ifndef HEADPID_H 
#define HEADPID_H 

class HeadPID {
    public: //En atributos publicos se definan los metodos de la clase
        PIDControl(double Kp, double Ki, double Kd, double dt); //Constructor de la clase
        void setTunings(double Kp, double Ki = 0, double Kd = 0); //Metodo para definir los valores de Kp, Ki y Kd. Ki y Kd son opcionales
        void setSetpoint(double setpoint); //Metodo para definir el setpoint
        double compute(double measured_value); //Metodo para calcular la salida del controlador PID

        private:
            //Atributos privados de la clase para Kp, Ki, Kd y dt
            double Kp;              //Ganancia proporcional
            double Ki;              //Ganancia integral
            double Kd;              //Ganancia derivativa
            double dt;              //Tiempo de muestreo
            //Atributos privados de la clase para el controlador PID
            double setpoint;        //Valor de referencia
            double measured_value;  //Valor medido
            double error;           //Error
            double previous_error;  //Error anterior
            double integral;        //Integral
            double derivative;      //Derivada

            //Atributos privados de la clase para el filtro IIR
            double error[3];        //Error en el filtro IIR
            double A0;              //Coeficientes del filtro IIR
            double A1;              //Coeficientes del filtro IIR
            double A2;              //Coeficientes del filtro IIR
    
            //Atributos privados de la clase para el filtro pasa baja en el termino derivativo
            double alpha;           //Constante de tiempo del filtro pasa baja
            double alpha_1;         //Variable auxiliar para el filtro pasa baja en el termino derivativo
            double alpha_2;         //Variable auxiliar para el filtro pasa baja en el termino derivativo
            double N;               //Numero de puntos del filtro pasa baja en el termino derivativo
            double fd0;             //Variable auxiliar para el filtro pasa baja en el termino derivativo
            double fd1;             //Variable auxiliar para el filtro pasa baja en el termino derivativo  
            double d0;              //Variable auxiliar para el filtro pasa baja en el termino derivativo
            double d1;              //Variable auxiliar para el filtro pasa baja en el termino derivativo 
};


